################################################################################
#                                                                              #
#                        Copyright (C) 2018 Kobra                              #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                                                                              #
################################################################################


import os 
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import sys
import urllib
import urllib2
import re
import webbrowser

from resources.libs import downloader, extract, vfs
from resources.libs.vfs import VFSClass


ADDON_ID				= 'plugin.program.xxxstream'
ADDON					= xbmcaddon.Addon(ADDON_ID)
DIALOG					= xbmcgui.Dialog()
DP						= xbmcgui.DialogProgress()
HOME					= xbmc.translatePath('special://home/')
ADDONS					= os.path.join(HOME, 'addons')
PACKAGES				= os.path.join(ADDONS, 'packages')
URL						= 'http://kodicustombuilds.com/adult/wizard/adultupdateminor.txt'
URL2					= 'http://kodicustombuilds.com/adult/wizard/adultupdatemajor.txt'
URL3					= 'http://kodicustombuilds.com/adult/kobra_xxx_stream_apk/kobra_xxx_stream_apk_update.xml'
USER_AGENT				= 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
DISABLE					= ADDON.getSetting('disableminorupdate')
DISABLE2				= ADDON.getSetting('disablemajorupdate')
DISABLE3				= ADDON.getSetting('cleartemponstart')
DISABLE4				= ADDON.getSetting('disableapkupdate')
DISABLEOFFER			= ADDON.getSetting('disableoffer')
INSTALLED				= ADDON.getSetting('installed')
INSTALLED2				= ADDON.getSetting('installed2')
KOBRA_XXX_APK_VERSION   = ADDON.getSetting('kobra_xxx_apk_version_number')
RUN						= xbmc.executebuiltin
IPVAN					="http://bit.ly/ipvanish_kodi"
INSTALL            		= 'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'


def openURL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def doUpdate(version, url):
	if DIALOG.yesno('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[COLOR ghostwhite][CR]NEW MINOR UPDATE AVAILABLE','','WOULD YOU LIKE TO INSTALL THIS UPDATE?[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, INSTALL[/COLOR]'):
		DP.create('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR ghostwhite]DOWNLOADING UPDATE[/COLOR]','', '[COLOR ghostwhite]PLEASE WAIT[/COLOR]')
		lib=os.path.join(PACKAGES, 'adultupdateminor.zip')
		try: os.remove(lib)
		except: pass
		downloader.download(url, lib, DP)
		time.sleep(2)
		DP.update(0,'','[COLOR ghostwhite]INSTALLING UPDATE[/COLOR]')
		time.sleep(2)
		extract.all(lib, HOME, DP)
		DP.close()
		ADDON.setSetting('installed', version)
		DIALOG.ok('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR ghostwhite]UPDATE[/COLOR] [COLOR lime]SUCCESSFUL[/COLOR]','[CR][COLOR ghostwhite]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] TO APPLY THE UPDATE[/COLOR]')
		try: os.remove(lib)
		except: pass
		time.sleep(2)
		RUN('ReloadSkin()')
		try: os.remove(lib)
		except: pass
	else: 
		pass


def doUpdate2(version, url):
	if DIALOG.yesno('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[COLOR ghostwhite][CR]NEW MAJOR UPDATE AVAILABLE','','WOULD YOU LIKE TO INSTALL THIS UPDATE?[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, INSTALL[/COLOR]'):
		DP.create('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR ghostwhite]DOWNLOADING UPDATE[/COLOR]','', '[COLOR ghostwhite]PLEASE WAIT[/COLOR]')
		lib=os.path.join(PACKAGES, 'adultupdatemajor.zip')
		try: os.remove(lib)
		except: pass
		downloader.download(url, lib, DP)
		time.sleep(2)
		DP.update(0,'','[COLOR ghostwhite]INSTALLING UPDATE[/COLOR]')
		time.sleep(2)
		extract.all(lib, HOME, DP)
		DP.close()
		ADDON.setSetting('installed2', version)
		DIALOG.ok('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[COLOR ghostwhite]UPDATE[/COLOR] [COLOR lime]SUCCESSFUL[/COLOR]','[COLOR ghostwhite]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] TO FORCE CLOSE KOBRA XXX STREAM TO APPLY CHANGES THEN PLEASE RESTART THE APPLICATION[/COLOR]')
		try: os.remove(lib)
		except: pass
		time.sleep(2)
		os._exit(1)
	else: 
		pass

def apk_install(version, url):
	if DIALOG.yesno("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM APK UPDATE[/COLOR]","","[COLOR ghostwhite]THERE IS AN UPDATE AVAILABLE FOR KOBRA XXX STREAM APPLICATION. WOULD YOU LIKE TO UPDATE THE APPLICATION NOW?[/COLOR]","","UPDATE NEXT TIME","UPDATE NOW"):
		path = os.path.join(xbmc.translatePath('special://home'), 'Kobra_Adult_APKs')
		lib=os.path.join(path, version+'.Kobra XXX Stream.apk')
		if not os.path.exists(path):	
			xbmcvfs.mkdir(path)
		else:
			pass
		try: os.remove(lib)
		except: pass
		DP.create("[COLOR darkred]KOBRA [/COLOR][COLOR ghostwhite]XXX STREAM APK UPDATE[/COLOR]"," ",'', " ")
		downloader.download(url, lib, DP)
		DP.close()
		RUN(INSTALL+lib+'")')
		ADDON.setSetting('kobra_xxx_apk_version_number', version)
		time.sleep(4)
		DIALOG.ok('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM APK UPDATE[/B][/COLOR]','[COLOR ghostwhite]UPDATE[/COLOR] [COLOR lime]SUCCESSFUL[/COLOR]','[COLOR ghostwhite]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] TO FORCE CLOSE KOBRA XXX STREAM TO APPLY CHANGES THEN PLEASE RESTART THE APPLICATION[/COLOR]')
		try: os.remove(lib)
		except: pass
		time.sleep(2)
		os._exit(1)
	else:
		pass

		
def check_kobra_xxx_stream_apk_update():
    vfs = VFSClass()
    mod = vfs.read_file('special://home/addons/plugin.program.xxxstream/resources/mod.txt')
	#mod = vfs.read_file('special://xbmc/addons/plugin.program.xxxstream/resources/mod.txt') 
    xbmc.log(msg=mod, level=xbmc.LOGNOTICE)
    link = openURL(URL3).replace('\n','').replace('\r','').replace('\t','')
    match = re.compile('name="Kobra XXX Stream Update".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
    if len(match) > 0:
        for version, url in match:
            if version > KOBRA_XXX_APK_VERSION:
                apk_install(version, url)
            else: 
                xbmc.log(msg="###   KOBRA XXX STREAM APK DOWNLOAD: No new apk avaliable.   ###", level=xbmc.LOGNOTICE)
    else:
        xbmc.log(msg="###   KOBRA XXX STREAM APK DOWNLOAD: Unable to grab apk.   ###", level=xbmc.LOGNOTICE)
		
		
def checkUpdateMinor():
	time.sleep(5)
	link = openURL(URL).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="minor".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
	if len(match) > 0:
		for version, url in match:
			if version > INSTALLED:
				doUpdate(version, url)
			else: 
				xbmc.log(msg="###   KOBRA: No new version of minor update avaliable.   ###", level=xbmc.LOGNOTICE)
	else:
		xbmc.log(msg="###   KOBRA: Unable to grab version of minor update.   ###", level=xbmc.LOGNOTICE)


def checkUpdateMajor():
	time.sleep(5)
	link = openURL(URL2).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="major".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
	if len(match) > 0:
		for version, url in match:
			if version > INSTALLED2:
				doUpdate2(version, url)
			else: 
				xbmc.log(msg="###   KOBRA: No new version of major update avaliable.   ###", level=xbmc.LOGNOTICE)
	else:
		xbmc.log(msg="###   KOBRA: Unable to grab version of major update.   ###", level=xbmc.LOGNOTICE)

def offer_popup():
	if DIALOG.yesno('[COLOR darkred][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]CYBER WEEK OFFER[/B][/COLOR]','[COLOR ghostwhite][CR]72% OFF IPVanish VPN','','Would you like to see this offer? [CR] To disable this popup go to Addons, Program Addons, Kobra XXX Stream Wizard, Settings, Auto Update Settings, Disable VPN Offer[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, OPEN OFFER[/COLOR]'):
		try: webbrowser.open_new ("https://www.ipvanish.com/ipvsave50/?a_aid=58df974346906&a_bid=48f95966")
		except: pass
		try: RUN("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+IPVAN+")")
		except: pass
		try: RUN("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+IPVAN+")")
		except: pass
		try: RUN("StartAndroidActivity(org.mozilla.tv.firefox,android.intent.action.VIEW,,"+IPVAN+")")
		except: pass		
		try: RUN("StartAndroidActivity(com.android.chrome,,,"+IPVAN+")")
		except: DIALOG.ok('[COLOR darkred][B][I]OOPS! [/I][/B][/COLOR][COLOR ghostwhite] [B]OOPS![/B][/COLOR]','[COLOR ghostwhite]SYSTEM[/COLOR] [COLOR red]ERROR[/COLOR]','[COLOR ghostwhite]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] NO SUITABLE BROWSWER INSTALLED[/COLOR]')
		# ADDON.setSetting('disableoffer', 'true')
	else: 
		pass

def delete_intro_voice():
	time.sleep(3)
	xbmcvfs.delete('special://xbmc/addons/resource.uisounds.kodi/resources/intro.wav')
	
if (__name__ == "__main__"):
	if not DISABLE4 == 'true':
		check_kobra_xxx_stream_apk_update()
	if not DISABLEOFFER == 'true':
		offer_popup()
	if not DISABLE == 'true':
		checkUpdateMinor()
	if not DISABLE2 == 'true':
		checkUpdateMajor()
	delete_intro_voice()